const doctorServices = require("./doctor.service");

module.exports = { doctorServices };
