const doctorController = require("./doctor.controller");

module.exports = { doctorController };
