please import  the database dump before start (db_dump/doctor.sql)
dbname: doctor

create api postman

localhost:3000/api/doctor

JSON exmp
    {
	"doctor_id": 2,
	"start_time": "6:00 AM",
	"end_time": "8:00 AM",
	"no_of_patients": 5
}


fetch api postman
localhost:3000/api/doctor/2020-08-80/1/2/10

